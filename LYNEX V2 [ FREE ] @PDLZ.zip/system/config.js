/*
┏━━━━━━━━━━━━━━━┓  
┃ RIKZZ BASE - WHATSAPP     
┣━━━━━━━━━━━━━━━┛
┃♕ Creator: RikzzZhiro           
┃♕ AI Helper: ChatGPT             
┃♔ Version: 1.0.0                   
┗━━━━━━━━━━━━━━━┛
*/
//========RIKZZ========
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6285748533018"] 
global.namabot = 'Lynex-v2'
//======================
global.mess = { 
owner: 'Waduhh! ,Lu bukan owner gw bg🗣️',
premium: 'Lah Lu siapa Njr, Bukan prem tai🐦',
succes: 'Success Bang😾'
}
//======================